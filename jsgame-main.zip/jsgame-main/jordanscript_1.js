//życie
function health1minus10(){
    let health = document.getElementById("health")
    health.value -= 10;
}
function health1plus10(){
    let health = document.getElementById("health")
    health.value += 10;
}